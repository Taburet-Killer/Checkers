package com.example.checkersd.models

import kotlinx.serialization.Serializable

@Serializable
data class GameState(
    val board: Array<Array<CheckersPiece?>> = createInitialBoard(),
    val currentPlayer: Player = Player.RED,
    val selectedPiece: Position? = null,
    val validMoves: List<Position> = emptyList(),
    val winner: Player? = null,
    val gameMode: GameMode = GameMode.PLAYER_VS_PLAYER,
    val botDifficulty: BotDifficulty = BotDifficulty.MEDIUM
) {
    companion object {
        fun createInitialBoard(): Array<Array<CheckersPiece?>> {
            val board = Array(8) { arrayOfNulls<CheckersPiece?>(8) }

            // Расстановка черных шашек
            for (row in 0..2) {
                for (col in 0..7) {
                    if ((row + col) % 2 == 1) {
                        board[row][col] = CheckersPiece(Player.BLACK)
                    }
                }
            }

            // Расстановка красных шашек
            for (row in 5..7) {
                for (col in 0..7) {
                    if ((row + col) % 2 == 1) {
                        board[row][col] = CheckersPiece(Player.RED)
                    }
                }
            }

            return board
        }
    }

    fun updateState(
        board: Array<Array<CheckersPiece?>> = this.board,
        currentPlayer: Player = this.currentPlayer,
        selectedPiece: Position? = this.selectedPiece,
        validMoves: List<Position> = this.validMoves,
        winner: Player? = this.winner,
        gameMode: GameMode = this.gameMode,
        botDifficulty: BotDifficulty = this.botDifficulty
    ): GameState {
        val newBoard = Array(8) { row ->
            Array(8) { col ->
                board[row][col]
            }
        }
        return GameState(
            board = newBoard,
            currentPlayer = currentPlayer,
            selectedPiece = selectedPiece,
            validMoves = validMoves,
            winner = winner,
            gameMode = gameMode,
            botDifficulty = botDifficulty
        )
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as GameState

        if (!board.contentDeepEquals(other.board)) return false
        if (currentPlayer != other.currentPlayer) return false
        if (selectedPiece != other.selectedPiece) return false
        if (validMoves != other.validMoves) return false
        if (winner != other.winner) return false
        if (gameMode != other.gameMode) return false
        if (botDifficulty != other.botDifficulty) return false

        return true
    }

    override fun hashCode(): Int {
        var result = board.contentDeepHashCode()
        result = 31 * result + currentPlayer.hashCode()
        result = 31 * result + (selectedPiece?.hashCode() ?: 0)
        result = 31 * result + validMoves.hashCode()
        result = 31 * result + (winner?.hashCode() ?: 0)
        result = 31 * result + gameMode.hashCode()
        result = 31 * result + botDifficulty.hashCode()
        return result
    }
}