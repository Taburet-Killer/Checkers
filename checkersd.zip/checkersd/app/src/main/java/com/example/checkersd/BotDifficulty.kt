package com.example.checkersd.models

enum class BotDifficulty {
    EASY, MEDIUM, HARD
}