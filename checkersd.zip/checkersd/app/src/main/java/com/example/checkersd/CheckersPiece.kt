package com.example.checkersd.models
import kotlinx.serialization.Serializable
@Serializable
data class CheckersPiece(
    val player: Player,
    val isKing: Boolean = false
)

enum class Player {
    RED, BLACK
}