package com.example.checkersd.models
// Position.kt
import kotlinx.serialization.Serializable
@Serializable
data class Position(val row: Int, val col: Int) {
    fun isValid(): Boolean = row in 0..7 && col in 0..7
}

