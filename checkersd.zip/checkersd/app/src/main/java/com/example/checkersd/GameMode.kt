package com.example.checkersd.models

enum class GameMode {
    PLAYER_VS_PLAYER,
    PLAYER_VS_BOT
}