package com.example.checkersd.models

data class BotMove(
    val from: Position,
    val to: Position,
    val score: Int = 0
)