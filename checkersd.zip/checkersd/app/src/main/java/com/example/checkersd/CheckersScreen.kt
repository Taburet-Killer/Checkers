package com.example.checkersd.ui.screens

import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.times
import com.example.checkersd.bot.BotPlayer
import com.example.checkersd.logic.GameLogic
import com.example.checkersd.models.BotDifficulty
import com.example.checkersd.models.GameMode
import com.example.checkersd.models.GameState
import com.example.checkersd.models.Position
import com.example.checkersd.models.Player
import kotlinx.coroutines.delay

@Composable
fun CheckersScreen() {
    // Храним настройки отдельно от состояния игры
    var gameSettings by remember {
        mutableStateOf(GameSettingsState())
    }
    var gameState by remember {
        mutableStateOf(createNewGameState(gameSettings))
    }
    var isBotThinking by remember { mutableStateOf(false) }

    // Сбрасываем игру при изменении настроек
    LaunchedEffect(gameSettings) {
        gameState = createNewGameState(gameSettings)
    }

    // Обработка хода бота
    LaunchedEffect(gameState.currentPlayer, gameState.winner) {
        if (gameSettings.gameMode == GameMode.PLAYER_VS_BOT &&
            gameState.currentPlayer == Player.BLACK &&
            gameState.winner == null &&
            !isBotThinking) {

            isBotThinking = true
            delay(1000) // Задержка для реалистичности

            val botMove = BotPlayer.makeMove(gameState, gameSettings.botDifficulty)
            botMove?.let { move ->
                gameState = GameLogic.makeMove(gameState, move.from, move.to)
            }

            isBotThinking = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF8B4513)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Шашки",
            modifier = Modifier.padding(16.dp),
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // Выбор режима игры и сложности
        GameSettings(
            gameSettings = gameSettings,
            onGameModeChanged = { newMode ->
                gameSettings = gameSettings.copy(gameMode = newMode)
            },
            onDifficultyChanged = { newDifficulty ->
                gameSettings = gameSettings.copy(botDifficulty = newDifficulty)
            }
        )

        Text(
            text = when {
                isBotThinking -> "Бот думает..."
                gameState.currentPlayer == Player.RED -> "Ход красных"
                else -> "Ход черных"
            },
            modifier = Modifier.padding(8.dp),
            fontSize = 20.sp,
            color = when {
                isBotThinking -> Color.Yellow
                gameState.currentPlayer == Player.RED -> Color.Red
                else -> Color.Black
            }
        )

        // Информация о режиме игры
        Text(
            text = when (gameSettings.gameMode) {
                GameMode.PLAYER_VS_PLAYER -> "Режим: 2 игрока"
                GameMode.PLAYER_VS_BOT -> "Режим: Игра с ботом (бот играет черными)"
            },
            modifier = Modifier.padding(4.dp),
            fontSize = 14.sp,
            color = Color.White
        )

        Spacer(modifier = Modifier.height(16.dp))

        BoardView(
            gameState = gameState,
            isBotThinking = isBotThinking,
            gameSettings = gameSettings,
            onPieceSelected = { position ->
                if (shouldBlockPlayerInput(gameState, isBotThinking, gameSettings)) {
                    return@BoardView
                }

                val piece = gameState.board[position.row][position.col]
                if (piece?.player == gameState.currentPlayer) {
                    val validMoves = GameLogic.getValidMoves(gameState.board, position)
                    gameState = gameState.updateState(
                        selectedPiece = position,
                        validMoves = validMoves
                    )
                }
            },
            onMoveMade = { toPosition ->
                if (shouldBlockPlayerInput(gameState, isBotThinking, gameSettings)) {
                    return@BoardView
                }

                gameState.selectedPiece?.let { fromPosition ->
                    gameState = GameLogic.makeMove(gameState, fromPosition, toPosition)
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = {
                    gameState = createNewGameState(gameSettings)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFCD853F))
            ) {
                Text("Новая игра", color = Color.White)
            }
        }

        gameState.winner?.let { winner ->
            Text(
                text = "Победили ${if (winner == Player.RED) "красные" else "черные"}!",
                modifier = Modifier.padding(16.dp),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Yellow
            )
        }
    }
}

// Модель для настроек игры
data class GameSettingsState(
    val gameMode: GameMode = GameMode.PLAYER_VS_PLAYER,
    val botDifficulty: BotDifficulty = BotDifficulty.MEDIUM
)

// Функция для создания нового состояния игры с учетом настроек
private fun createNewGameState(settings: GameSettingsState): GameState {
    return GameState(
        gameMode = settings.gameMode,
        botDifficulty = settings.botDifficulty
    )
}

// Функция для проверки, нужно ли блокировать ввод игрока
private fun shouldBlockPlayerInput(
    gameState: GameState,
    isBotThinking: Boolean,
    settings: GameSettingsState
): Boolean {
    return gameState.winner != null ||
            isBotThinking ||
            (settings.gameMode == GameMode.PLAYER_VS_BOT && gameState.currentPlayer == Player.BLACK)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameSettings(
    gameSettings: GameSettingsState,
    onGameModeChanged: (GameMode) -> Unit,
    onDifficultyChanged: (BotDifficulty) -> Unit
) {
    var gameModeExpanded by remember { mutableStateOf(false) }
    var difficultyExpanded by remember { mutableStateOf(false) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Выбор режима игры
            ExposedDropdownMenuBox(
                expanded = gameModeExpanded,
                onExpandedChange = { gameModeExpanded = !gameModeExpanded }
            ) {
                TextField(
                    value = when (gameSettings.gameMode) {
                        GameMode.PLAYER_VS_PLAYER -> "2 игрока"
                        GameMode.PLAYER_VS_BOT -> "Игра с ботом"
                    },
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = gameModeExpanded) },
                    modifier = Modifier.menuAnchor(),
                    label = { Text("Режим игры") }
                )

                DropdownMenu(
                    expanded = gameModeExpanded,
                    onDismissRequest = { gameModeExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("2 игрока") },
                        onClick = {
                            onGameModeChanged(GameMode.PLAYER_VS_PLAYER)
                            gameModeExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Игра с ботом") },
                        onClick = {
                            onGameModeChanged(GameMode.PLAYER_VS_BOT)
                            gameModeExpanded = false
                        }
                    )
                }
            }

            // Выбор сложности бота (только в режиме с ботом)
            if (gameSettings.gameMode == GameMode.PLAYER_VS_BOT) {
                ExposedDropdownMenuBox(
                    expanded = difficultyExpanded,
                    onExpandedChange = { difficultyExpanded = !difficultyExpanded }
                ) {
                    TextField(
                        value = when (gameSettings.botDifficulty) {
                            BotDifficulty.EASY -> "Легкий"
                            BotDifficulty.MEDIUM -> "Средний"
                            BotDifficulty.HARD -> "Сложный"
                        },
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = difficultyExpanded) },
                        modifier = Modifier.menuAnchor(),
                        label = { Text("Сложность") }
                    )

                    DropdownMenu(
                        expanded = difficultyExpanded,
                        onDismissRequest = { difficultyExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Легкий") },
                            onClick = {
                                onDifficultyChanged(BotDifficulty.EASY)
                                difficultyExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Средний") },
                            onClick = {
                                onDifficultyChanged(BotDifficulty.MEDIUM)
                                difficultyExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Сложный") },
                            onClick = {
                                onDifficultyChanged(BotDifficulty.HARD)
                                difficultyExpanded = false
                            }
                        )
                    }
                }
            }
        }

        // Отображаем текущую сложность
        if (gameSettings.gameMode == GameMode.PLAYER_VS_BOT) {
            Text(
                text = "Сложность бота: ${
                    when (gameSettings.botDifficulty) {
                        BotDifficulty.EASY -> "Легкий"
                        BotDifficulty.MEDIUM -> "Средний"
                        BotDifficulty.HARD -> "Сложный"
                    }
                }",
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier.padding(4.dp)
            )
        }
    }
}

@Composable
fun BoardView(
    gameState: GameState,
    isBotThinking: Boolean,
    gameSettings: GameSettingsState,
    onPieceSelected: (Position) -> Unit,
    onMoveMade: (Position) -> Unit
) {
    Box(
        modifier = Modifier
            .size(300.dp)
            .padding(16.dp)
    ) {
        // Отрисовка доски
        Canvas(
            modifier = Modifier
                .size(300.dp)
        ) {
            val cellSize = size.width / 8

            for (row in 0..7) {
                for (col in 0..7) {
                    val isLight = (row + col) % 2 == 0
                    val color = if (isLight) Color(0xFFDEB887) else Color(0xFF8B4513)

                    drawRect(
                        color = color,
                        topLeft = Offset(col * cellSize, row * cellSize),
                        size = Size(cellSize, cellSize)
                    )

                    val position = Position(row, col)

                    // Подсветка выбранной клетки
                    if (position == gameState.selectedPiece) {
                        drawRect(
                            color = Color.Yellow.copy(alpha = 0.5f),
                            topLeft = Offset(col * cellSize, row * cellSize),
                            size = Size(cellSize, cellSize)
                        )
                    }

                    // Подсветка возможных ходов
                    if (gameState.validMoves.contains(position)) {
                        drawCircle(
                            color = Color.Green.copy(alpha = 0.5f),
                            center = Offset(
                                col * cellSize + cellSize / 2,
                                row * cellSize + cellSize / 2
                            ),
                            radius = cellSize / 4
                        )
                    }

                    // Рисование шашек
                    gameState.board[row][col]?.let { piece ->
                        val pieceColor = when (piece.player) {
                            Player.RED -> Color.Red
                            Player.BLACK -> Color.Black
                        }

                        drawCircle(
                            color = pieceColor,
                            center = Offset(
                                col * cellSize + cellSize / 2,
                                row * cellSize + cellSize / 2
                            ),
                            radius = cellSize / 2 - 4.dp.toPx()
                        )

                        // Обводка для дамки
                        if (piece.isKing) {
                            drawCircle(
                                color = Color.Yellow,
                                center = Offset(
                                    col * cellSize + cellSize / 2,
                                    row * cellSize + cellSize / 2
                                ),
                                radius = cellSize / 2 - 2.dp.toPx(),
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }
                    }
                }
            }
        }

        // Сетка для обработки нажатий
        for (row in 0..7) {
            for (col in 0..7) {
                Box(
                    modifier = Modifier
                        .size(300.dp / 8)
                        .offset(
                            x = (col * 300.dp / 8),
                            y = (row * 300.dp / 8)
                        )
                        .clickable {
                            val position = Position(row, col)

                            if (shouldBlockPlayerInput(gameState, isBotThinking, gameSettings)) {
                                return@clickable
                            }

                            if (gameState.validMoves.contains(position)) {
                                onMoveMade(position)
                            } else {
                                val piece = gameState.board[row][col]
                                if (piece?.player == gameState.currentPlayer) {
                                    onPieceSelected(position)
                                }
                            }
                        }
                )
            }
        }
    }
}

// Добавьте эти импорты


@Composable
fun Dp.toPx(): Float {
    return this.value * LocalDensity.current.density
}