package com.example.checkersd.logic

import com.example.checkersd.models.CheckersPiece
import com.example.checkersd.models.GameState
import com.example.checkersd.models.Player
import com.example.checkersd.models.Position
import kotlin.math.abs

object GameLogic {

    fun getValidMoves(board: Array<Array<CheckersPiece?>>, position: Position): List<Position> {
        val piece = board[position.row][position.col] ?: return emptyList()

        return if (piece.isKing) {
            getKingValidMoves(board, position, piece)
        } else {
            getRegularValidMoves(board, position, piece)
        }
    }

    private fun getRegularValidMoves(
        board: Array<Array<CheckersPiece?>>,
        position: Position,
        piece: CheckersPiece
    ): List<Position> {
        val moves = mutableListOf<Position>()
        val jumpMoves = checkRegularJumpMoves(board, position, piece, mutableSetOf())

        if (jumpMoves.isNotEmpty()) {
            moves.addAll(jumpMoves)
        } else {
            checkRegularSimpleMoves(board, position, piece, moves)
        }

        return moves
    }

    private fun getKingValidMoves(
        board: Array<Array<CheckersPiece?>>,
        position: Position,
        piece: CheckersPiece
    ): List<Position> {
        val moves = mutableListOf<Position>()
        val jumpMoves = checkKingJumpMoves(board, position, piece, mutableSetOf())

        if (jumpMoves.isNotEmpty()) {
            moves.addAll(jumpMoves)
        } else {
            checkKingSimpleMoves(board, position, piece, moves)
        }

        return moves
    }

    private fun checkRegularSimpleMoves(
        board: Array<Array<CheckersPiece?>>,
        position: Position,
        piece: CheckersPiece,
        moves: MutableList<Position>
    ) {
        val directions = getRegularMoveDirections(piece)

        for (direction in directions) {
            val newRow = position.row + direction.first
            val newCol = position.col + direction.second
            val newPos = Position(newRow, newCol)

            if (newPos.isValid() && board[newRow][newCol] == null) {
                moves.add(newPos)
            }
        }
    }

    private fun checkKingSimpleMoves(
        board: Array<Array<CheckersPiece?>>,
        position: Position,
        piece: CheckersPiece,
        moves: MutableList<Position>
    ) {
        val directions = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)

        for (direction in directions) {
            var currentRow = position.row + direction.first
            var currentCol = position.col + direction.second

            // Дамка может ходить на любое количество пустых клеток по диагонали
            while (currentRow in 0..7 && currentCol in 0..7) {
                if (board[currentRow][currentCol] == null) {
                    moves.add(Position(currentRow, currentCol))
                    currentRow += direction.first
                    currentCol += direction.second
                } else {
                    break // Наткнулись на другую шашку - дальше нельзя
                }
            }
        }
    }

    private fun checkRegularJumpMoves(
        board: Array<Array<CheckersPiece?>>,
        position: Position,
        piece: CheckersPiece,
        visited: MutableSet<Position>
    ): List<Position> {
        val moves = mutableListOf<Position>()
        val directions = getRegularMoveDirections(piece)

        for (direction in directions) {
            val jumpRow = position.row + direction.first * 2
            val jumpCol = position.col + direction.second * 2
            val jumpPos = Position(jumpRow, jumpCol)

            val middleRow = position.row + direction.first
            val middleCol = position.col + direction.second
            val middlePos = Position(middleRow, middleCol)

            if (jumpPos.isValid() &&
                board[middleRow][middleCol] != null &&
                board[middleRow][middleCol]?.player != piece.player &&
                board[jumpRow][jumpCol] == null &&
                !visited.contains(jumpPos)) {

                moves.add(jumpPos)
                visited.add(jumpPos)

                // Рекурсивная проверка множественных прыжков
                val tempBoard = createTempBoard(board)
                // Удаляем сбитую шашку сразу
                tempBoard[middleRow][middleCol] = null
                tempBoard[jumpRow][jumpCol] = piece
                tempBoard[position.row][position.col] = null

                val additionalJumps = checkRegularJumpMoves(tempBoard, jumpPos, piece, visited)
                moves.addAll(additionalJumps)
            }
        }
        return moves
    }

    private fun checkKingJumpMoves(
        board: Array<Array<CheckersPiece?>>,
        position: Position,
        piece: CheckersPiece,
        visited: MutableSet<Position>
    ): List<Position> {
        val moves = mutableListOf<Position>()
        val directions = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)

        for (direction in directions) {
            var currentRow = position.row + direction.first
            var currentCol = position.col + direction.second
            var foundEnemy = false
            var enemyRow = -1
            var enemyCol = -1

            // Ищем вражескую шашку для прыжка
            while (currentRow in 0..7 && currentCol in 0..7 && !foundEnemy) {
                when {
                    board[currentRow][currentCol] == null -> {
                        // Пустая клетка - продолжаем искать
                        currentRow += direction.first
                        currentCol += direction.second
                    }
                    board[currentRow][currentCol]?.player != piece.player -> {
                        // Нашли вражескую шашку
                        foundEnemy = true
                        enemyRow = currentRow
                        enemyCol = currentCol
                        currentRow += direction.first
                        currentCol += direction.second
                    }
                    else -> break // Нашли свою шашку - дальше нельзя
                }
            }

            // Если нашли вражескую шашку, проверяем можно ли через нее прыгнуть
            if (foundEnemy && currentRow in 0..7 && currentCol in 0..7 &&
                board[currentRow][currentCol] == null) {

                val jumpPos = Position(currentRow, currentCol)
                if (!visited.contains(jumpPos)) {
                    moves.add(jumpPos)
                    visited.add(jumpPos)

                    // Рекурсивная проверка множественных прыжков для дамки
                    val tempBoard = createTempBoard(board)
                    // Удаляем сбитую шашку сразу
                    tempBoard[enemyRow][enemyCol] = null
                    tempBoard[currentRow][currentCol] = piece
                    tempBoard[position.row][position.col] = null

                    val additionalJumps = checkKingJumpMoves(tempBoard, jumpPos, piece, visited)
                    moves.addAll(additionalJumps)
                }
            }
        }
        return moves
    }

    private fun getRegularMoveDirections(piece: CheckersPiece): List<Pair<Int, Int>> {
        return if (piece.player == Player.RED) {
            listOf(-1 to -1, -1 to 1) // Красные ходят вверх
        } else {
            listOf(1 to -1, 1 to 1) // Черные ходят вниз
        }
    }

    private fun createTempBoard(board: Array<Array<CheckersPiece?>>): Array<Array<CheckersPiece?>> {
        return Array(8) { row ->
            Array(8) { col ->
                board[row][col]
            }
        }
    }

    fun makeMove(
        currentState: GameState,
        from: Position,
        to: Position
    ): GameState {
        // Создаем глубокую копию доски
        val newBoard = Array(8) { row ->
            Array(8) { col ->
                currentState.board[row][col]
            }
        }

        val piece = newBoard[from.row][from.col]!!

        // Перемещение шашки
        newBoard[to.row][to.col] = piece
        newBoard[from.row][from.col] = null

        // Обработка захвата шашек
        handleCapture(newBoard, from, to, piece)

        // Проверка на превращение в дамку
        if (!piece.isKing && ((piece.player == Player.RED && to.row == 0) ||
                    (piece.player == Player.BLACK && to.row == 7))) {
            newBoard[to.row][to.col] = piece.copy(isKing = true)
        }

        // Проверка победы
        val winner = checkWinner(newBoard)

        return GameState(
            board = newBoard,
            currentPlayer = if (currentState.currentPlayer == Player.RED) Player.BLACK else Player.RED,
            selectedPiece = null,
            validMoves = emptyList(),
            winner = winner,
            gameMode = currentState.gameMode,
            botDifficulty = currentState.botDifficulty
        )
    }

    private fun handleCapture(
        board: Array<Array<CheckersPiece?>>,
        from: Position,
        to: Position,
        piece: CheckersPiece
    ) {
        if (piece.isKing) {
            handleKingCapture(board, from, to, piece)
        } else {
            handleRegularCapture(board, from, to)
        }
    }

    private fun handleRegularCapture(
        board: Array<Array<CheckersPiece?>>,
        from: Position,
        to: Position
    ) {
        val rowDiff = to.row - from.row
        val colDiff = to.col - from.col

        // Если это прыжок (ход на 2 клетки)
        if (abs(rowDiff) == 2 && abs(colDiff) == 2) {
            val capturedRow = from.row + rowDiff / 2
            val capturedCol = from.col + colDiff / 2
            board[capturedRow][capturedCol] = null

            // Проверяем возможность дальнейших прыжков из новой позиции
            val additionalJumps = checkRegularJumpMoves(board, to, board[to.row][to.col]!!, mutableSetOf())
            if (additionalJumps.isNotEmpty()) {
                // Если есть дальнейшие прыжки, не меняем игрока
                // Это обрабатывается на уровне UI через validMoves
            }
        }
    }

    private fun handleKingCapture(
        board: Array<Array<CheckersPiece?>>,
        from: Position,
        to: Position,
        piece: CheckersPiece
    ) {
        val rowDirection = if (to.row > from.row) 1 else -1
        val colDirection = if (to.col > from.col) 1 else -1

        var currentRow = from.row + rowDirection
        var currentCol = from.col + colDirection

        var capturedPieceFound = false

        // Проходим по пути и ищем вражеские шашки
        while (currentRow != to.row && currentCol != to.col) {
            if (board[currentRow][currentCol] != null) {
                if (board[currentRow][currentCol]?.player != piece.player) {
                    // Нашли вражескую шашку - удаляем ее
                    if (!capturedPieceFound) {
                        board[currentRow][currentCol] = null
                        capturedPieceFound = true
                    } else {
                        // Если нашли вторую шашку - это ошибка, дамка не может прыгать через несколько шашек за один ход
                        break
                    }
                } else {
                    // Нашли свою шашку - это ошибка
                    break
                }
            }
            currentRow += rowDirection
            currentCol += colDirection
        }
    }

    private fun checkWinner(board: Array<Array<CheckersPiece?>>): Player? {
        val redPieces = board.flatten().count { it?.player == Player.RED }
        val blackPieces = board.flatten().count { it?.player == Player.BLACK }

        // Также проверяем, есть ли у игрока возможные ходы
        val redHasMoves = hasValidMoves(board, Player.RED)
        val blackHasMoves = hasValidMoves(board, Player.BLACK)

        return when {
            redPieces == 0 || !redHasMoves -> Player.BLACK
            blackPieces == 0 || !blackHasMoves -> Player.RED
            else -> null
        }
    }

    private fun hasValidMoves(board: Array<Array<CheckersPiece?>>, player: Player): Boolean {
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = board[row][col]
                if (piece?.player == player) {
                    val validMoves = getValidMoves(board, Position(row, col))
                    if (validMoves.isNotEmpty()) {
                        return true
                    }
                }
            }
        }
        return false
    }
}