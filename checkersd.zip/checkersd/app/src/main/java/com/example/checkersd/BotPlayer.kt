package com.example.checkersd.bot

import com.example.checkersd.logic.GameLogic
import com.example.checkersd.models.BotDifficulty
import com.example.checkersd.models.BotMove
import com.example.checkersd.models.CheckersPiece
import com.example.checkersd.models.GameState
import com.example.checkersd.models.Player
import com.example.checkersd.models.Position
import kotlin.random.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object BotPlayer {

    fun makeMove(gameState: GameState, difficulty: BotDifficulty = BotDifficulty.MEDIUM): BotMove? {
        return when (difficulty) {
            BotDifficulty.EASY -> makeEasyMove(gameState)
            BotDifficulty.MEDIUM -> makeMediumMove(gameState)
            BotDifficulty.HARD -> makeHardMove(gameState, depth = 3)
        }
    }

    private fun makeEasyMove(gameState: GameState): BotMove? {
        val allMoves = getAllPossibleMoves(gameState)
        return allMoves.randomOrNull()
    }

    private fun makeMediumMove(gameState: GameState): BotMove? {
        val allMoves = getAllPossibleMoves(gameState)
        if (allMoves.isEmpty()) return null

        // Оцениваем каждый ход и выбираем лучший
        val scoredMoves = allMoves.map { move ->
            val score = evaluateMove(gameState, move)
            move.copy(score = score)
        }

        // Выбираем ход с максимальным счетом
        return scoredMoves.maxByOrNull { it.score }
    }

    private fun makeHardMove(gameState: GameState, depth: Int): BotMove? {
        val allMoves = getAllPossibleMoves(gameState)
        if (allMoves.isEmpty()) return null

        var bestMove: BotMove? = null
        var bestScore = Int.MIN_VALUE

        for (move in allMoves) {
            // Создаем новое состояние после хода
            val newState = GameLogic.makeMove(gameState, move.from, move.to)

            // Используем минимакс для оценки
            val score = minimax(newState, depth - 1, false, Int.MIN_VALUE, Int.MAX_VALUE)

            if (score > bestScore) {
                bestScore = score
                bestMove = move.copy(score = score)
            }
        }

        return bestMove
    }

    private fun minimax(
        state: GameState,
        depth: Int,
        isMaximizing: Boolean,
        alpha: Int,
        beta: Int
    ): Int {
        // Базовый случай - достигнута максимальная глубина или игра окончена
        if (depth == 0 || state.winner != null) {
            return evaluateBoard(state.board, Player.BLACK) // Бот играет черными
        }

        val allMoves = getAllPossibleMoves(state)

        if (isMaximizing) {
            var maxEval = Int.MIN_VALUE
            var currentAlpha = alpha

            for (move in allMoves) {
                val newState = GameLogic.makeMove(state, move.from, move.to)
                val eval = minimax(newState, depth - 1, false, currentAlpha, beta)
                maxEval = maxOf(maxEval, eval)
                currentAlpha = maxOf(currentAlpha, eval)
                if (beta <= currentAlpha) break // Отсечение beta
            }
            return maxEval
        } else {
            var minEval = Int.MAX_VALUE
            var currentBeta = beta

            for (move in allMoves) {
                val newState = GameLogic.makeMove(state, move.from, move.to)
                val eval = minimax(newState, depth - 1, true, alpha, currentBeta)
                minEval = minOf(minEval, eval)
                currentBeta = minOf(currentBeta, eval)
                if (currentBeta <= alpha) break // Отсечение alpha
            }
            return minEval
        }
    }

    private fun getAllPossibleMoves(gameState: GameState): List<BotMove> {
        val moves = mutableListOf<BotMove>()
        val currentPlayer = gameState.currentPlayer

        // Проходим по всем клеткам доски
        for (row in 0..7) {
            for (col in 0..7) {
                val piece = gameState.board[row][col]
                if (piece?.player == currentPlayer) {
                    val position = Position(row, col)
                    val validMoves = GameLogic.getValidMoves(gameState.board, position)

                    for (moveTo in validMoves) {
                        moves.add(BotMove(position, moveTo))
                    }
                }
            }
        }

        return moves
    }

    private fun evaluateMove(gameState: GameState, move: BotMove): Int {
        var score = 0

        // Базовые бонусы
        score += if (isCaptureMove(gameState, move)) 50 else 0 // Захват шашки
        score += if (becomesKing(gameState, move)) 30 else 0   // Стать дамкой

        // Позиционные бонусы
        score += getPositionScore(move.to)

        // Защита своих шашек
        score += if (isProtectedPosition(gameState, move.to)) 10 else 0

        // Атака центра
        score += getCenterControlScore(move.to)

        return score
    }

    private fun evaluateBoard(board: Array<Array<CheckersPiece?>>, botPlayer: Player): Int {
        var score = 0

        for (row in 0..7) {
            for (col in 0..7) {
                val piece = board[row][col] ?: continue

                val pieceValue = when {
                    piece.isKing -> 30 // Дамка ценнее
                    else -> 10         // Обычная шашка
                }

                val positionBonus = getPositionScore(Position(row, col))

                if (piece.player == botPlayer) {
                    score += pieceValue + positionBonus
                } else {
                    score -= pieceValue + positionBonus
                }
            }
        }

        return score
    }

    private fun isCaptureMove(gameState: GameState, move: BotMove): Boolean {
        val rowDiff = abs(move.to.row - move.from.row)
        return rowDiff == 2 // Прыжок всегда на 2 клетки
    }

    private fun becomesKing(gameState: GameState, move: BotMove): Boolean {
        val piece = gameState.board[move.from.row][move.from.col]!!
        return !piece.isKing && (
                (piece.player == Player.RED && move.to.row == 0) ||
                        (piece.player == Player.BLACK && move.to.row == 7)
                )
    }

    private fun isProtectedPosition(gameState: GameState, position: Position): Boolean {
        // Проверяем, защищена ли позиция соседними шашками
        val directions = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)
        val currentPlayer = gameState.currentPlayer

        for (direction in directions) {
            val neighborRow = position.row + direction.first
            val neighborCol = position.col + direction.second

            if (neighborRow in 0..7 && neighborCol in 0..7) {
                val neighborPiece = gameState.board[neighborRow][neighborCol]
                if (neighborPiece?.player == currentPlayer) {
                    return true
                }
            }
        }

        return false
    }

    private fun getPositionScore(position: Position): Int {
        // Даем бонусы за хорошие позиции
        return when {
            // Угловые позиции обычно хороши для защиты
            (position.row == 0 || position.row == 7) && (position.col == 0 || position.col == 7) -> 5
            // Близко к превращению в дамку
            position.row == 1 || position.row == 6 -> 3
            // Центральные позиции
            position.row in 3..4 && position.col in 3..4 -> 2
            else -> 0
        }
    }

    private fun getCenterControlScore(position: Position): Int {
        // Бонус за контроль центра
        val centerDistance = abs(position.row - 3.5) + abs(position.col - 3.5)
        return (7 - centerDistance).toInt()
    }
}